//
//  ZonaColors.swift
//  PapalotePrueba
//
//  Created by Acker Enif Saldaña Polanco on 18/10/24.
//

import SwiftUI

struct ZonaColors {
    // Colores para cada zona
    static let pertenezco = Color(red: 190/255, green: 214/255, blue: 0/255)  // Pantone 382 C
    static let comunico = Color(red: 0/255, green: 123/255, blue: 192/255)     // Pantone 307 C
    static let expreso = Color(red: 255/255, green: 102/255, blue: 0/255)      // Pantone 151 C
    static let comprendo = Color(red: 146/255, green: 39/255, blue: 143/255)   // Pantone 2593 C
    static let soy = Color(red: 224/255, green: 32/255, blue: 55/255)          // Pantone 199 C
    // static let pertenezcoSecundario
    
    // Función para obtener el color según la zona
    static func colorForZona(_ zona: String) -> Color {
        switch zona {
        case "Pertenezco":
            return pertenezco
        case "Comunico":
            return comunico
        case "Expreso":
            return expreso
        case "Comprendo":
            return comprendo
        case "Soy":
            return soy
        default:
            return .gray // Un color por defecto si la zona no coincide
        }
    }
}
