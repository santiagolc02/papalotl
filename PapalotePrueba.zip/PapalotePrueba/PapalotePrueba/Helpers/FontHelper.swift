//
//  FontHelper.swift
//  PapalotePrueba
//
//  Created by Acker Enif Saldaña Polanco on 22/10/24.
//

import SwiftUI

struct FontHelper {
    
    // MARK: - Apercu Mono Fonts
    
    static func apercuMonoBold(size: CGFloat) -> Font {
        return Font.custom("ApercuMonoPro-Bold", size: size) // Nombre interno confirmado
    }
    
    static func apercuMonoLight(size: CGFloat) -> Font {
        return Font.custom("ApercuMonoPro-Light", size: size)
    }
    
    static func apercuMonoMedium(size: CGFloat) -> Font {
        return Font.custom("ApercuMonoPro-Medium", size: size)
    }
    
    static func apercuMonoRegular(size: CGFloat) -> Font {
        return Font.custom("ApercuMonoPro-Regular", size: size)
    }
    
    // MARK: - Apercu Pro Fonts
    
    static func apercuProBlack(size: CGFloat) -> Font {
        return Font.custom("ApercuPro-Black", size: size)
    }
    
    static func apercuProBlackItalic(size: CGFloat) -> Font {
        return Font.custom("ApercuPro-BlackItalic", size: size)
    }
    
    static func apercuProBold(size: CGFloat) -> Font {
        return Font.custom("ApercuPro-Bold", size: size)
    }
    
    static func apercuProBoldItalic(size: CGFloat) -> Font {
        return Font.custom("ApercuPro-BoldItalic", size: size)
    }
    
    static func apercuProExtraLight(size: CGFloat) -> Font {
        return Font.custom("ApercuPro-ExtraLight", size: size)
    }
    
    static func apercuProExtraLightItalic(size: CGFloat) -> Font {
        return Font.custom("ApercuPro-ExtraLightItalic", size: size)
    }
    
    static func apercuProItalic(size: CGFloat) -> Font {
        return Font.custom("ApercuPro-Italic", size: size)
    }
    
    static func apercuProLight(size: CGFloat) -> Font {
        return Font.custom("ApercuPro-Light", size: size)
    }
    
    static func apercuProLightItalic(size: CGFloat) -> Font {
        return Font.custom("ApercuPro-LightItalic", size: size)
    }
    
    static func apercuProMedium(size: CGFloat) -> Font {
        return Font.custom("ApercuPro-Medium", size: size)
    }
    
    static func apercuProMediumItalic(size: CGFloat) -> Font {
        return Font.custom("ApercuPro-MediumItalic", size: size)
    }
    
    static func apercuProRegular(size: CGFloat) -> Font {
        return Font.custom("ApercuPro-Regular", size: size)
    }
    
    static func apercuProThin(size: CGFloat) -> Font {
        return Font.custom("ApercuPro-Thin", size: size)
    }
    
    static func apercuProThinItalic(size: CGFloat) -> Font {
        return Font.custom("ApercuPro-ThinItalic", size: size)
    }
}


