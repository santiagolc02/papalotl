//
//  NFCReader.swift
//  PapalotePrueba
//
//  Created by Acker Enif Saldaña Polanco on 24/10/24.
//

/*
 import SwiftUI
 
 @IBAction func scanNFC(_ sender: Any) {
 guard NFCDEFReaderSession.readingAvailable else {
 let alertController = UIAlertController(title: "Scanning Not Supported",
 message: "This device doesn't support tag scanning.",
 preferredStyle: .alert)
 alertController.addAction(UIAlertAction(title:"OK", style: .default, handler: nil))
 self.present(alertController, animated: true, completion: nil)
 return
 }
 
 session = NFCDEFReaderSession(delegate: self, queue: nil, invalidateAfterFirstRead: false)
 session?.alertMessage = "Hold your iPhone near the item to learn more about it."
 session?.begin()
 }
 
 func readerSession(_ session: NFCDEFReaderSession, didDetectNDEFs messages: [NFCNDEFMessage]) {
 
 DispatchQueue.main.async{
 self.detectedMessages.append(contentsOf: messages)
 self.tableView.reloadData()
 }
 }
 */
