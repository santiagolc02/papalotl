//
//  ActividadesViewModel.swift
//  PapalotePrueba
//
//  Created by Acker Enif Saldaña Polanco on 23/10/24.
//

import SwiftUI
import FirebaseFirestore
import Firebase

class ActividadesViewModel: ObservableObject {
    @Published var actividadesPertenezco: [String] = []
    @Published var actividadesComunico: [String] = []
    @Published var actividadesSoy: [String] = []
    @Published var actividadesComprendo: [String] = []
    @Published var actividadesExpreso: [String] = []
    @Published var actividadesCargadas: Bool = false  // Para indicar si las actividades han sido completamente cargadas

    init() {
        loadActividades()
    }

    func loadActividades() {
        let db = Firestore.firestore()
        db.collection("actividad").getDocuments { snapshot, error in
            if let error = error {
                print("Error al cargar actividades: \(error)")
                return
            }

            // Limpiar las listas antes de volver a cargar
            self.actividadesPertenezco.removeAll()
            self.actividadesComunico.removeAll()
            self.actividadesSoy.removeAll()
            self.actividadesComprendo.removeAll()
            self.actividadesExpreso.removeAll()

            // Recorrer los documentos de Firebase
            snapshot?.documents.forEach { document in
                let data = document.data()

                var idZona: Int = 0
                if let zonaInt = data["idZona"] as? Int {
                    idZona = zonaInt
                } else if let zonaString = data["idZona"] as? String, let zonaInt = Int(zonaString) {
                    idZona = zonaInt
                } else if let zonaDouble = data["idZona"] as? Double {
                    idZona = Int(zonaDouble)
                } else {
                    print("Zona no válida para el documento \(document.documentID)")
                }

                let nombreActividad = data["nombre"] as? String ?? "Actividad desconocida"
                print("Cargando actividad '\(nombreActividad)' para zona con id \(idZona)")

                // Actualizamos las actividades según el idZona
                switch idZona {
                case 1:
                    self.actividadesPertenezco.append(nombreActividad)
                case 2:
                    self.actividadesComunico.append(nombreActividad)
                case 3:
                    self.actividadesSoy.append(nombreActividad)
                case 4:
                    self.actividadesComprendo.append(nombreActividad)
                case 5:
                    self.actividadesExpreso.append(nombreActividad)
                default:
                    print("Zona con id \(idZona) no es válida para la actividad '\(nombreActividad)'")
                }
            }

            // Una vez que todas las actividades se hayan cargado, establecemos el estado en true
            DispatchQueue.main.async {
                self.actividadesCargadas = true
            }
        }
    }
}







