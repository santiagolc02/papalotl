//
//  ContentView.swift
//  PapalotePrueba
//
//  Created by Acker Enif Saldaña Polanco on 18/09/24.
//

import SwiftUI
import FirebaseAuth

struct ContentView: View {
    
    @State private var isLoggedIn: Bool = false
    @State private var showSignup: Bool = false
    
    var body: some View {
        NavigationStack {
            if isLoggedIn {
                // Si el usuario ya está logueado, mostrar la MainPage
                MainPage(isLoggedIn: $isLoggedIn)
            } else {
                ZStack {
                    if showSignup {
                        SignUp(showSignup: $showSignup, isLoggedIn: $isLoggedIn)
                            .transition(.move(edge: .bottom))
                    } else {
                        Login(isLoggedIn: $isLoggedIn, showSignup: $showSignup)
                            .transition(.move(edge: .top))
                    }
                }
                .animation(.easeInOut(duration: 0.5), value: showSignup)
            }
        }
        .onAppear {
            // Verificar si ya hay un usuario autenticado cuando se carga la vista
            checkLoginStatus()
        }
    }

    // Función para verificar si el usuario ya está logueado
    func checkLoginStatus() {
        if Auth.auth().currentUser != nil {
            // Si hay un usuario logueado, actualizar el estado a "logueado"
            isLoggedIn = true
        } else {
            // Si no hay usuario logueado, mantener el valor en false
            isLoggedIn = false
        }
    }
}







