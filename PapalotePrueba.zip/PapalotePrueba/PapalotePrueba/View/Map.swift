//
//  Map.swift
//  PapalotePrueba
//
//  Created by Acker Enif Saldaña Polanco on 21/09/24.
//

import SwiftUI

struct Map: View {
    var body: some View {
        Text("Mapa")
    }
}

#Preview {
    Map()
}
