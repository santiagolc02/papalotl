//
//  PapalotePruebaApp.swift
//  PapalotePrueba
//
//  Created by Acker Enif Saldaña Polanco on 18/09/24.
//

import SwiftUI
import Firebase

@main
struct PapalotePruebaApp: App {
    
    init() {
            FirebaseApp.configure()
        }
    
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
