//
//  PapalotePruebaTests.swift
//  PapalotePruebaTests
//
//  Created by Acker Enif Saldaña Polanco on 18/09/24.
//

import Testing
@testable import PapalotePrueba

struct PapalotePruebaTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
